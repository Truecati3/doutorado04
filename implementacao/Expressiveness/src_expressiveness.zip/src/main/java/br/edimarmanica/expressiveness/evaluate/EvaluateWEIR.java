/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edimarmanica.expressiveness.evaluate;

import br.edimarmanica.dataset.Attribute;
import br.edimarmanica.dataset.Configuration;
import br.edimarmanica.dataset.Site;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author edimar
 */
public class EvaluateWEIR {

    private Site site;
    private static final String LOCAL_SEPARATOR = "&_&";

    public EvaluateWEIR(Site site) {
        this.site = site;
    }

    private Set<String> loadMyResults(Attribute attribute) {
        Set<String> values = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(Configuration.PATH_EXPRESSIVENESS + site.getPath() + "/extracted_values/" + attribute.getAttributeID() + ".csv"))) {
            String linha;
            br.readLine(); //descarta o cabeçalho
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(Configuration.COLUMN_SEPARATOR);
                values.add(partes[0] + LOCAL_SEPARATOR + partes[1]);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EvaluateWEIR.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EvaluateWEIR.class.getName()).log(Level.SEVERE, null, ex);
        }
        return values;
    }

    private Set<String> loadGroundTruth(Attribute attribute) throws SiteWithoutThisAttribute {
        Set<String> values = new HashSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(Configuration.PATH_BASE + site.getGroundTruthPath()))) {
            String linha;
            String[] partes = br.readLine().split(";"); //verificar a coluna que contém o atributo desejado
            int attributeIndex;
            for (attributeIndex = 0; attributeIndex < partes.length; attributeIndex++) {
                if (partes[attributeIndex].trim().equals(attribute.getAttributeIDbyDataset())) {
                    break;
                }
            }

            if (attributeIndex >= partes.length) { //esse site não tem esse atributo
                throw new SiteWithoutThisAttribute(attribute.getAttributeID(), site.getFolderName());
            }

            while ((linha = br.readLine()) != null) {
                partes = linha.split(";");
                
                if ( attributeIndex < partes.length && !partes[attributeIndex].trim().isEmpty()) {
                    String value = partes[attributeIndex];
                    if (value.startsWith("\"") && value.endsWith("\"")) {
                        value = value.substring(1, value.length() - 1);
                        value = value.replaceAll("\"\"", "\"");
                    }
                    values.add(Configuration.PATH_BASE + site.getDomain().getDataset().getFolderName() + "/" + partes[0] + LOCAL_SEPARATOR + value);
                }
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EvaluateWEIR.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EvaluateWEIR.class.getName()).log(Level.SEVERE, null, ex);
        }
        return values;
    }

    private void printMetrics(Attribute attribute) {


        Set<String> groundtruth;
        try {
            groundtruth = loadGroundTruth(attribute);
        } catch (SiteWithoutThisAttribute ex) {
            return; //site sem esse atributo
        }
        
        Set<String> results = loadMyResults(attribute);

        Set<String> intersection = new HashSet<>();
        intersection.addAll(results);
        intersection.retainAll(groundtruth);

        double recall = (double) intersection.size() / groundtruth.size();
        double precision = (double) intersection.size() / results.size();

        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String formattedDate = formatter.format(date);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(Configuration.PATH_EXPRESSIVENESS + "/" + site.getDomain().getPath() + "/result.csv", true))) {
            bw.write("dataset;" + site.getDomain().getDataset().getFolderName() + ";domain;" + site.getDomain().getFolderName()
                    + ";site;" + site.getFolderName() + "attribute;" + attribute.getAttributeID() + ";relevantes;"+groundtruth.size()+";recuperados;"+results.size()+";relevantes recuperados; "+intersection.size()+";recall;" + recall + ";precision;" + precision + ";date;" + formattedDate);
            bw.newLine();
        } catch (IOException ex) {
            Logger.getLogger(EvaluateWEIR.class.getName()).log(Level.SEVERE, null, ex);
        }


        try (BufferedWriter bw = new BufferedWriter(new FileWriter(Configuration.PATH_EXPRESSIVENESS + "/" + site.getPath() + "/log.txt", true))) {
            bw.write("\n\n*************" + formattedDate + " - " + attribute.getAttributeID() + "********************************\n");
            bw.write("dataset;" + site.getDomain().getDataset().getFolderName() + ";domain;" + site.getDomain().getFolderName()
                    + ";site;" + site.getFolderName() + "attribute;" + attribute.getAttributeID() + ";relevantes;"+groundtruth.size()+";recuperados;"+results.size()+";relevantes recuperados; "+intersection.size()+";recall;" + recall + ";precision;" + precision + ";date;" + formattedDate);            bw.newLine();
            bw.write("--------------------------------------------\n");
            bw.write("Relevantes não recuperados (Problema de recall):\n");
            for (String rel : groundtruth) {
                if (!results.contains(rel)) {
                    String[] partes = rel.split(LOCAL_SEPARATOR);
                    bw.write("Faltando: [" + partes[1] + "] na página: " + partes[0]);
                    bw.newLine();
                }
            }
            bw.write("--------------------------------------------\n");
            bw.write("Irrelevantes recuperados (Problema de precision):\n");
            for (String rel : results) {
                if (!groundtruth.contains(rel)) {
                    String[] partes = rel.split(LOCAL_SEPARATOR);
                    bw.write("Faltando: [" + partes[1] + "] na página: " + partes[0]);
                    bw.newLine();
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(EvaluateWEIR.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void printMetrics() {
        for (Attribute attr : site.getDomain().getAttributes()) {
            printMetrics(attr);
        }
    }

    public static void main(String[] args) {
        EvaluateWEIR eval = new EvaluateWEIR(br.edimarmanica.dataset.weir.book.Site.BOOKMOOCH);
        //eval.printMetrics(br.edimarmanica.dataset.weir.book.Attribute.AUTHOR);
        eval.printMetrics();
    }
}
