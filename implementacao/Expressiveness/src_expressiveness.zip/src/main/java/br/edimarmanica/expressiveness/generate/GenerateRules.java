/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edimarmanica.expressiveness.generate;

import br.edimarmanica.dataset.Configuration;
import br.edimarmanica.dataset.Site;
import br.edimarmanica.expressiveness.generate.beans.AttributeInfo;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author edimar
 */
public class GenerateRules {

    private static List<AttributeInfo> loadAttributeInfo(Site site) {
        List<AttributeInfo> attrsInfo = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(Configuration.PATH_EXPRESSIVENESS + site.getPath() + "/attributes_info.csv"))) {
            String linha;
            br.readLine(); //pulando o cabeçalho
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(Configuration.COLUMN_SEPARATOR);
                attrsInfo.add(new AttributeInfo(partes[0], partes[1], partes[2], partes[3]));
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GenerateRules.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GenerateRules.class.getName()).log(Level.SEVERE, null, ex);
        }

        return attrsInfo;
    }

    /**
     *
     * @return the cypher rules === Map<Attribute,Rule>
     */
    public static Map<String, String> getRules(Site site) {
        Map<String, String> rules = new HashMap<>();
        List<AttributeInfo> attrsInfo = loadAttributeInfo(site);
        for (AttributeInfo attr : attrsInfo) {
            rules.put(attr.getAttribute(), CypherNotation.getNotation(attr.getLabel(), attr.getUniquePathLabel(), attr.getUniquePathValue()));
        }
        return rules;
    }

    public static void printRules(Site site) {
        Map<String, String> rules = getRules(site);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(Configuration.PATH_EXPRESSIVENESS + site.getPath() + "/generated_rules.csv"))) {
            bw.write("attribute" + Configuration.COLUMN_SEPARATOR + "rule\n"); //cabeçalho
            for (String attr : rules.keySet()) {
                bw.write(attr + Configuration.COLUMN_SEPARATOR + rules.get(attr).replaceAll("\n", " ") + "\n");
            }
        } catch (IOException ex) {
            Logger.getLogger(GenerateRules.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {

        printRules(br.edimarmanica.dataset.weir.book.Site.BOOKMOOCH);
    }
}
