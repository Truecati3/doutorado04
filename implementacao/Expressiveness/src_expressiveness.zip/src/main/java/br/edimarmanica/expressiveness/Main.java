/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edimarmanica.expressiveness;

/**
 *
 * @author edimar
 */
public class Main {
    public static void main(String[] args) {
        //antes de tudo tem que carregar o site no neo4j e gerar os templates (nessa etapa ainda não precisa dos templates pois estou fazendo manualmente)
        //primeiro chama o generate rules
        //depois o ExtractValues
        //Depois o Evaluate
    }
}
