/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edimarmanica.expressiveness;

/**
 *
 * @author edimar
 */
public class Teste {

    public static void main(String[] args) {
        String uniquePathLabel = "/html[1]/body[2]/text()[15]";

        System.out.println(uniquePathLabel.replaceAll("\\[\\d+\\]", ""));
    }
}
