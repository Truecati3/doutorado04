/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edimarmanica.expressiveness.extract;

import br.edimarmanica.dataset.Configuration;
import br.edimarmanica.dataset.Site;
import br.edimarmanica.expressiveness.generate.GenerateRules;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author edimar
 */
public class ExtractValues {

    private QueryNeo4J query = new QueryNeo4J();
    private Site site;

    public ExtractValues(Site site) {
        this.site = site;
    }

    /**
     *
     * @param site
     * @return Map<Attribute,Rule>
     */
    public Map<String, String> loadRules() {
        Map<String, String> rules = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(Configuration.PATH_EXPRESSIVENESS + site.getPath() + "/generated_rules.csv"))) {
            String linha;
            br.readLine(); //descarta o cabeçalho
            while ((linha = br.readLine()) != null) {
                String[] partes = linha.split(Configuration.COLUMN_SEPARATOR);
                rules.put(partes[0], partes[1]);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ExtractValues.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ExtractValues.class.getName()).log(Level.SEVERE, null, ex);
        }

        return rules;
    }

    public void printExtractedValues() {
        Map<String, String> rules = loadRules();

        for (String attr : rules.keySet()) {
            printExtractedValues(site, attr, rules.get(attr));
        }
    }

    private void printExtractedValues(Site site, String attribute, String rule) {
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(Configuration.PATH_EXPRESSIVENESS + site.getPath() + "/extracted_values/" + attribute + ".csv"))) {
            bw.write("URL" + Configuration.COLUMN_SEPARATOR + "EXTRACTED VALUE\n"); //cabeçalho
            Map<String, String> extractedValues = query.extract(rule);
            for (String url : extractedValues.keySet()) {
                bw.write(url + Configuration.COLUMN_SEPARATOR + extractedValues.get(url) + "\n");
            }
        } catch (IOException ex) {
            Logger.getLogger(GenerateRules.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        ExtractValues extract = new ExtractValues(br.edimarmanica.dataset.weir.book.Site.BOOKMOOCH);
        extract.printExtractedValues();
    }
}
